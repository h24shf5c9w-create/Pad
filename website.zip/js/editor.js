/* ============================================================
   Sample Editor
   The selection window is a fixed-width region dragged across
   the waveform. Only two transforms are written per frame —
   no canvas is redrawn while dragging.
   ============================================================ */
(function (LP) {
  'use strict';

  var MIN_SEL_PX = 22;      // keeps a 0.1 s slice grabbable on a phone
  var LENGTHS = [0.1, 0.2, 0.5, 1, 2, 3, 4, 5];

  var dom = null;
  var selStart = 0;         // seconds
  var reqLen = 0.5;         // requested length from the dropdown
  var volume = 30;          // percent; 30 reproduces the unamplified level
  var effDur = 0.5;         // clamped to the recording length
  var curLeft = 0;          // px
  var selPx = 0;
  var wrapW = 0;

  var dragging = false;
  var grabOffset = 0;
  var wrapLeft = 0;
  var pendingLeft = null;
  var rafId = 0;
  var previewSrc = null;
  var saveTimer = null;

  function init() {
    dom = LP.ui.dom;

    dom.srcSelect.addEventListener('change', function () {
      selectSource(dom.srcSelect.value);
    });

    dom.lenSelect.addEventListener('change', function () {
      reqLen = parseFloat(dom.lenSelect.value) || 0.5;
      layout(true);
      persistPrefs();
    });

    dom.volSlider.addEventListener('input', function () {
      setVolume(parseInt(dom.volSlider.value, 10));
      /* Applies straight to a pad that already holds a sample, so
         "louder" is one drag away instead of a drag plus a save. */
      if (LP.pads.get(LP.ui.state.activePad)) {
        LP.pads.setVolume(LP.ui.state.activePad, volume);
      }
      persistPrefs();
    });

    dom.btnPreview.addEventListener('click', preview);
    dom.btnSave.addEventListener('click', save);
    dom.btnClearPad.addEventListener('click', clearActivePad);

    dom.waveWrap.addEventListener('pointerdown', onPointerDown, { passive: false });
    dom.waveWrap.addEventListener('pointermove', onPointerMove, { passive: false });
    dom.waveWrap.addEventListener('pointerup', onPointerUp);
    dom.waveWrap.addEventListener('pointercancel', onPointerUp);

    dom.selWindow.addEventListener('keydown', onKeyDown);
  }

  /* ── Geometry ─────────────────────────────────────────────
     start seconds  <->  left pixels
     Travel is measured against the *rendered* width so the very
     end of the recording stays reachable even when the window
     is being held at its minimum touch size. */

  function src() { return LP.ui.editSource(); }
  function buffer() { var x = src(); return x ? x.buffer : null; }
  function total() { var x = src(); return x ? x.duration : 0; }
  function range() { return Math.max(0, total() - effDur); }
  function travel() { return Math.max(0, wrapW - selPx); }

  function startToLeft(s) {
    var r = range(), t = travel();
    if (r <= 0 || t <= 0) return 0;
    return (s / r) * t;
  }

  function leftToStart(px) {
    var r = range(), t = travel();
    if (r <= 0 || t <= 0) return 0;
    return (px / t) * r;
  }

  function clampStart(s) {
    var r = range();
    if (!(s > 0)) return 0;
    return s > r ? r : s;
  }

  function layout(keepStart) {
    if (!dom || !buffer()) return;
    var dur = total();
    wrapW = dom.waveWrap.clientWidth || 0;
    if (!wrapW || !dur) return;

    /* A recording shorter than the requested length is simply
       played whole. */
    effDur = Math.min(reqLen, dur);

    var geomPx = (effDur / dur) * wrapW;
    selPx = Math.max(MIN_SEL_PX, Math.min(wrapW, geomPx));

    dom.selWindow.style.width = selPx + 'px';
    dom.selWindow.classList.toggle('is-narrow', selPx < 52);

    if (keepStart !== false) selStart = clampStart(selStart);
    applyLeft(startToLeft(selStart));
    updateReadout();
  }

  function applyLeft(px) {
    curLeft = px;
    dom.selWindow.style.transform = 'translateX(' + px + 'px)';
    dom.waveSel.style.transform = 'translateX(' + (-px) + 'px)';
  }

  function setVolume(v) {
    volume = Math.max(0, Math.min(100, isNaN(v) ? LP.audio.DEFAULT_VOLUME : v));
    dom.volValue.textContent = volume + '%';
    dom.volSlider.style.setProperty('--fill', volume + '%');
    if (dom.volSlider.value !== String(volume)) dom.volSlider.value = String(volume);
  }

  function updateReadout() {
    var fmt = LP.ui.formatPrecise;
    dom.editorRange.textContent = fmt(selStart) + ' → ' + fmt(selStart + effDur);
    dom.selWindow.setAttribute('aria-valuemin', '0');
    dom.selWindow.setAttribute('aria-valuemax', range().toFixed(2));
    dom.selWindow.setAttribute('aria-valuenow', selStart.toFixed(2));
    dom.selWindow.setAttribute('aria-valuetext',
      selStart.toFixed(2) + ' to ' + (selStart + effDur).toFixed(2) + ' seconds');
  }

  /* ── Dragging ─────────────────────────────────────────────── */

  function canDrag() {
    return LP.ui.state.mode === 'customize' && !!buffer();
  }

  function onPointerDown(e) {
    if (!canDrag()) return;
    e.preventDefault();
    LP.audio.unlock();

    var rect = dom.waveWrap.getBoundingClientRect();
    wrapLeft = rect.left;
    wrapW = rect.width;

    var insideSelection = dom.selWindow.contains(e.target);
    if (insideSelection) {
      grabOffset = e.clientX - (wrapLeft + curLeft);
    } else {
      /* Tapping the waveform jumps the window under the finger. */
      grabOffset = selPx / 2;
      commitLeft(e.clientX - wrapLeft - grabOffset);
    }

    dragging = true;
    dom.selWindow.classList.add('is-dragging');
    try { dom.waveWrap.setPointerCapture(e.pointerId); } catch (err) {}
  }

  function onPointerMove(e) {
    if (!dragging) return;
    e.preventDefault();
    pendingLeft = e.clientX - wrapLeft - grabOffset;
    if (!rafId) rafId = requestAnimationFrame(flushDrag);
  }

  function flushDrag() {
    rafId = 0;
    if (pendingLeft === null) return;
    commitLeft(pendingLeft);
    pendingLeft = null;
  }

  function commitLeft(px) {
    var t = travel();
    if (px < 0) px = 0;
    if (px > t) px = t;
    selStart = clampStart(leftToStart(px));
    applyLeft(px);
    updateReadout();
  }

  function onPointerUp(e) {
    if (!dragging) return;
    dragging = false;
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    if (pendingLeft !== null) { commitLeft(pendingLeft); pendingLeft = null; }
    dom.selWindow.classList.remove('is-dragging');
    try { dom.waveWrap.releasePointerCapture(e.pointerId); } catch (err) {}
  }

  function onKeyDown(e) {
    if (!canDrag()) return;
    var step = e.shiftKey ? 0.5 : 0.05;
    var next = selStart;
    if (e.key === 'ArrowLeft') next = selStart - step;
    else if (e.key === 'ArrowRight') next = selStart + step;
    else if (e.key === 'Home') next = 0;
    else if (e.key === 'End') next = range();
    else return;
    e.preventDefault();
    selStart = clampStart(next);
    applyLeft(startToLeft(selStart));
    updateReadout();
  }

  /* ── Pad binding ──────────────────────────────────────────── */

  /* Rebuilds the sound dropdown: instruments first, then recordings. */
  function refreshSources(preferred) {
    if (!dom) return;
    var all = LP.sources.all;
    dom.srcSelect.innerHTML = '';
    var groups = [
      { label: 'Instruments', items: all.filter(function (x) { return x.kind === 'inst'; }) },
      { label: 'Recordings', items: all.filter(function (x) { return x.kind === 'rec'; }) }
    ];
    groups.forEach(function (g) {
      if (!g.items.length) return;
      var og = document.createElement('optgroup');
      og.label = g.label;
      g.items.forEach(function (item) {
        var o = document.createElement('option');
        o.value = item.id;
        o.textContent = item.name;
        og.appendChild(o);
      });
      dom.srcSelect.appendChild(og);
    });

    var want = preferred || LP.ui.state.editSrc;
    if (!want || !LP.sources.get(want)) want = LP.sources.firstId();
    LP.ui.state.editSrc = want;
    if (want) dom.srcSelect.value = want;
  }

  function selectSource(id) {
    var next = LP.sources.get(id);
    if (!next) return;
    LP.ui.state.editSrc = id;
    dom.srcSelect.value = id;
    selStart = 0;
    if (LP.app && LP.app.redraw) LP.app.redraw();
    layout();
    LP.ui.renderEditorVisibility();
  }

  function openPad(index) {
    if (!dom) return;
    dom.editorPadLabel.textContent = 'Pad ' + (index + 1);
    var slot = LP.pads.get(index);

    if (slot && LP.sources.get(slot.src)) {
      LP.ui.state.editSrc = slot.src;
      dom.srcSelect.value = slot.src;
      if (LP.app && LP.app.redraw) LP.app.redraw();
    }

    if (slot) {
      reqLen = nearestLength(slot.len || slot.duration);
      dom.lenSelect.value = String(reqLen);
      selStart = slot.start;
      setVolume(typeof slot.vol === 'number' ? slot.vol : LP.audio.DEFAULT_VOLUME);
    } else {
      setVolume(volume);
    }
    dom.btnClearPad.hidden = !slot;
    dom.editorHint.textContent = slot
      ? 'Drag to move, then save to overwrite this pad.'
      : 'Drag the highlighted window across the waveform.';

    layout();
  }

  function nearestLength(value) {
    var best = LENGTHS[0], bestDiff = Infinity;
    for (var i = 0; i < LENGTHS.length; i++) {
      var d = Math.abs(LENGTHS[i] - value);
      if (d < bestDiff) { bestDiff = d; best = LENGTHS[i]; }
    }
    return best;
  }

  function preview() {
    if (!buffer()) return;
    LP.audio.unlock();
    LP.audio.stopSource(previewSrc);
    previewSrc = LP.audio.play(buffer(), selStart, effDur, volume);
  }

  function save() {
    if (!buffer()) return;
    var index = LP.ui.state.activePad;
    LP.audio.unlock();
    LP.pads.assign(index, LP.ui.state.editSrc, selStart, effDur, reqLen, volume);
    LP.pads.trigger(index);

    dom.btnClearPad.hidden = false;
    dom.editorHint.textContent = 'Drag to move, then save to overwrite this pad.';
    LP.ui.setStatus('Saved to pad ' + (index + 1) + ' · ' +
      effDur.toFixed(2) + 's from ' + selStart.toFixed(2) + 's · ' + volume + '%');

    var label = dom.btnSave.textContent;
    dom.btnSave.textContent = 'Saved ✓';
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(function () { dom.btnSave.textContent = label; }, 900);
  }

  function clearActivePad() {
    var index = LP.ui.state.activePad;
    LP.pads.clear(index);
    dom.btnClearPad.hidden = true;
    dom.editorHint.textContent = 'Drag the highlighted window across the waveform.';
    LP.ui.setStatus('Pad ' + (index + 1) + ' cleared');
  }

  function reset() {
    selStart = 0;
    effDur = Math.min(reqLen, 0);
    curLeft = 0;
    if (dom) {
      dom.selWindow.style.transform = 'translateX(0px)';
      dom.waveSel.style.transform = 'translateX(0px)';
      dom.btnClearPad.hidden = true;
    }
  }

  function persistPrefs() {
    if (LP.app && LP.app.persist) LP.app.persist();
  }

  LP.editor = {
    init: init,
    layout: layout,
    openPad: openPad,
    refreshSources: refreshSources,
    selectSource: selectSource,
    preview: preview,
    save: save,
    reset: reset,
    setLength: function (v) {
      reqLen = nearestLength(v);
      if (dom) dom.lenSelect.value = String(reqLen);
    },
    setVolume: function (v) { if (dom) setVolume(v); },
    get length() { return reqLen; },
    get volume() { return volume; },
    get selection() { return { start: selStart, duration: effDur }; }
  };
})(window.LP = window.LP || {});
